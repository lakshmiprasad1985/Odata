using CustomerODataService.Domain.Entities;

namespace CustomerODataService.Application.Interfaces
{
    public interface ICustomerRepository
    {
        IQueryable<Customer> GetCustomers();
        Task<Customer> GetCustomerByIdAsync(int id);
        Task<Customer> CreateCustomerAsync(Customer customer);
        Task<Customer> UpdateCustomerAsync(Customer customer);
        Task DeleteCustomerAsync(int id);
    }
} 