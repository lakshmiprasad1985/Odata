using CustomerODataService.Application.Interfaces;
using CustomerODataService.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;

namespace CustomerODataService.Api.Controllers
{
    public class CustomersController : ODataController
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomersController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        /// <summary>
        /// Retrieves all customers with OData query capabilities
        /// </summary>
        /// <remarks>
        /// Sample OData queries:
        /// GET /odata/Customers?$filter=FirstName eq 'John'
        /// GET /odata/Customers?$orderby=LastName
        /// GET /odata/Customers?$top=5&amp;$skip=5
        /// GET /odata/Customers?$select=FirstName,LastName
        /// </remarks>
        [EnableQuery]
        public IActionResult Get()
        {
            return Ok(_customerRepository.GetCustomers());
        }

        /// <summary>
        /// Retrieves a specific customer by id
        /// </summary>
        [EnableQuery]
        public async Task<IActionResult> Get([FromRoute] int key)
        {
            var customer = await _customerRepository.GetCustomerByIdAsync(key);
            if (customer == null)
            {
                return NotFound();
            }
            return Ok(customer);
        }

        /// <summary>
        /// Creates a new customer
        /// </summary>
        public async Task<IActionResult> Post([FromBody] Customer customer)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var created = await _customerRepository.CreateCustomerAsync(customer);
            return Created(created);
        }

        /// <summary>
        /// Updates an existing customer
        /// </summary>
        public async Task<IActionResult> Put([FromRoute] int key, [FromBody] Customer customer)
        {
            if (key != customer.Id)
            {
                return BadRequest();
            }

            await _customerRepository.UpdateCustomerAsync(customer);
            return Updated(customer);
        }

        /// <summary>
        /// Deletes a customer
        /// </summary>
        public async Task<IActionResult> Delete([FromRoute] int key)
        {
            await _customerRepository.DeleteCustomerAsync(key);
            return NoContent();
        }
    }
} 