using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace CustomerODataService.Api.Swagger
{
    public class ODataParametersSwaggerFilter : IOperationFilter
    {
        private readonly IEnumerable<OpenApiParameter> _odataParameters = new[]
        {
            new OpenApiParameter
            {
                Name = "$select",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Select specific fields (e.g., firstName,lastName)"
            },
            new OpenApiParameter
            {
                Name = "$expand",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Expand related entities"
            },
            new OpenApiParameter
            {
                Name = "$filter",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Filter results (e.g., firstName eq 'John')"
            },
            new OpenApiParameter
            {
                Name = "$orderby",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Order results (e.g., lastName desc)"
            },
            new OpenApiParameter
            {
                Name = "$top",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "integer", Format = "int32" },
                Description = "Limit number of results"
            },
            new OpenApiParameter
            {
                Name = "$skip",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "integer", Format = "int32" },
                Description = "Skip number of results"
            },
            new OpenApiParameter
            {
                Name = "$count",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "boolean" },
                Description = "Include count of results"
            }
        };

        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            if (context.ApiDescription.HttpMethod != "GET") return;

            operation.Parameters ??= new List<OpenApiParameter>();

            foreach (var parameter in _odataParameters)
            {
                operation.Parameters.Add(parameter);
            }
        }
    }
} 