using CustomerODataService.Application.Interfaces;
using CustomerODataService.Domain.Entities;
using CustomerODataService.Infrastructure.Data;
using CustomerODataService.Infrastructure.Repositories;
using Microsoft.AspNetCore.OData;
using Microsoft.EntityFrameworkCore;
using Microsoft.OData.Edm;
using Microsoft.OData.ModelBuilder;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.AspNetCore.Cors;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
static IEdmModel GetEdmModel()
{
    var builder = new ODataConventionModelBuilder();
    builder.EntitySet<Customer>("Customers");
    return builder.GetEdmModel();
}

// Add controllers with OData support
builder.Services.AddControllers()
    .AddOData(opt => opt
        .AddRouteComponents("odata", GetEdmModel())
        .Select()
        .Filter()
        .OrderBy()
        .SetMaxTop(100)
        .Count()
        .Expand());

// Add DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("CustomerDb"));

// Add Repository
builder.Services.AddScoped<ICustomerRepository, CustomerRepository>();

// Configure Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Version = "v1",
        Title = "Customer OData API",
        Description = "A sample API using OData for customer management"
    });

    // Configure operation IDs
    options.CustomOperationIds(apiDesc =>
    {
        return apiDesc.TryGetMethodInfo(out System.Reflection.MethodInfo methodInfo) ? methodInfo.Name : null;
    });

    // Add OData query parameters for GET operations
    options.OperationFilter<SwaggerODataParametersFilter>();
});

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        builder =>
        {
            builder
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader()
                .WithExposedHeaders("OData-Version", "OData-MaxVersion");
        });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger(c => 
    {
        c.PreSerializeFilters.Add((swagger, httpReq) =>
        {
            swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"{httpReq.Scheme}://{httpReq.Host.Value}" } };
        });
    });
    
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "Customer OData API v1");
        options.RoutePrefix = string.Empty;
        options.EnableDeepLinking();
        options.DisplayOperationId();
    });

    // Seed initial data
    using (var scope = app.Services.CreateScope())
    {
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
        if (!context.Customers.Any())
        {
            context.Customers.AddRange(
                new Customer
                {
                    Id = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    Email = "john.doe@example.com",
                    PhoneNumber = "1234567890",
                    DateOfBirth = new DateTime(1990, 1, 1),
                    CreatedAt = DateTime.UtcNow
                },
                new Customer
                {
                    Id = 2,
                    FirstName = "Jane",
                    LastName = "Smith",
                    Email = "jane.smith@example.com",
                    PhoneNumber = "0987654321",
                    DateOfBirth = new DateTime(1992, 5, 15),
                    CreatedAt = DateTime.UtcNow
                }
            );
            context.SaveChanges();
        }
    }
}

// Configure the HTTP request pipeline.
app.UseHttpsRedirection();
app.UseRouting();
app.UseCors("AllowAll");
app.UseAuthorization();

// Add OData route prefix
app.UseODataRouteDebug();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();

public class SwaggerODataParametersFilter : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        if (context.ApiDescription.HttpMethod != "GET") return;

        operation.Parameters ??= new List<OpenApiParameter>();

        var odataParameters = new[]
        {
            new OpenApiParameter
            {
                Name = "$select",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Select specific fields (e.g., firstName,lastName)"
            },
            new OpenApiParameter
            {
                Name = "$expand",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Expand related entities"
            },
            new OpenApiParameter
            {
                Name = "$filter",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Filter results (e.g., firstName eq 'John')"
            },
            new OpenApiParameter
            {
                Name = "$orderby",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "string" },
                Description = "Order results (e.g., lastName desc)"
            },
            new OpenApiParameter
            {
                Name = "$top",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "integer", Format = "int32" },
                Description = "Limit number of results"
            },
            new OpenApiParameter
            {
                Name = "$skip",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "integer", Format = "int32" },
                Description = "Skip number of results"
            },
            new OpenApiParameter
            {
                Name = "$count",
                In = ParameterLocation.Query,
                Required = false,
                Schema = new OpenApiSchema { Type = "boolean" },
                Description = "Include count of results"
            }
        };

        foreach (var parameter in odataParameters)
        {
            if (!operation.Parameters.Any(p => p.Name == parameter.Name))
            {
                operation.Parameters.Add(parameter);
            }
        }
    }
} 